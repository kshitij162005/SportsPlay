import { MapPin as LucideMapPin } from 'lucide-react-native';

export default function MapPin(props: any) {
  return <LucideMapPin {...props} />;
}